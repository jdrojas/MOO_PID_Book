function Ms=MsCalc(P,C)
My=1/(1+P*C);
Ms=norm(My,inf);